# Henrick Man: El Corazón de Aurora — actualización

Abrir `UnityProject` con Unity 6000.3.17f1 y cargar `Assets/HenrickMan/Scenes/CiudadAurora.unity`. Para jugar sin el editor: `Builds/HenrickMan.exe`. Mantener la carpeta HenrickMan_Data y las bibliotecas junto al ejecutable.

## Novedades
- Personaje Zhongli suministrado por el usuario, con sus texturas originales y rig.
- Once animaciones descargadas de Adobe Mixamo: reposo, caminar, correr, salto, caída, aterrizaje, golpe, esquiva, reacción al daño, interacción y victoria. Asociadas a los estados correspondientes del controlador.
- Menú con nueva aventura, continuar checkpoint, opciones, créditos y repetición del cómic.
- Introducción de cuatro viñetas generadas con IA, subtítulos en español, avance con Espacio y omisión con Escape.
- Ciudad flotante generada en Unity: cuatro islas, puentes, torres solares, vegetación, turbinas animadas, cascadas estilizadas, arcos y plataforma hidráulica móvil.
- Opciones reales de sombras, antialiasing y límite de 60/120 FPS. El renderizador integrado actual no tiene DLSS configurado; no se añadió una opción ficticia.
- HUD actualizado con barras de vida, energía y Aurora; objetivo contextual y salud del Guardián.

## Controles

WASD mover; ratón cámara; Espacio saltar (doble salto tras el primer relé); Shift correr; C esquivar; Q cambiar energía; clic izquierdo atacar; clic derecho usar la habilidad o planear con el poder eólico; E activar; R modo Aurora con carga completa; Escape pausar.

## Recorrido
1. Primera isla: acercarse al relé dorado y pulsar E usando Solar.
2. Segunda isla: cambiar con Q a Eólico y activar el relé verde.
3. Tercera isla: cambiar a Hidráulico y activar el relé azul.
4. Cuarta isla: derrotar al Guardián y activar el núcleo. Los relés guardan posición y progreso localmente.

## Créditos y archivos
Zhongli, de Little Cammie, descargado originalmente de Sketchfab por el usuario. Ver `Zhongli_LICENSE.txt` (CC BY 4.0 y enlace de origen). Animaciones de Adobe Mixamo. El personaje no es un diseño original del equipo.

`UnityProject/Assets/HenrickMan/Models/Zhongli`: FBX descargados, clips editables y texturas. `Resources/Zhongli.prefab`: personaje usado en el juego. `Resources/AuroraComic.png`: atlas de cuatro viñetas generado con ImageGen. `Blender/Characters/Zhongli_imported.blend`: importación editable. `Exports/Mixamo/Zhongli_ForMixamo.fbx`: archivo enviado a Mixamo. Copia anterior en `Backups/Before_Zhongli_20261119`.

## Verificación y alcance
Compilación Windows correcta. Prueba automática del ejecutable: once clips presentes, tres relés activados y victoria alcanzada; resultados en `integration-test.txt`. Esa prueba mueve al personaje mediante posiciones programadas y no demuestra un recorrido manual completo. En Unity se verificaron menú, introducción, texturas, proporciones, salto y esquiva.

Sigue siendo un prototipo: combate por distancia/dirección, enemigos estilizados, un escenario y audio básico. No hay mundos adicionales ni cinemáticas 3D. No se importaron ciudades de Sketchfab: el entorno activo se construye en Unity. El rig de origen requiere normalización de escala durante la animación; conviene sustituirla por un rig humanoide normalizado antes de una producción final. No se ha realizado una medición formal de rendimiento.
