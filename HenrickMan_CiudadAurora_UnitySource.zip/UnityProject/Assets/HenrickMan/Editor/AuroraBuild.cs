using UnityEditor;using UnityEditor.SceneManagement;using UnityEngine;
public static class AuroraBuild {[MenuItem("Aurora/Build Windows")] public static void Create(){var s=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);new GameObject("Aurora systems").AddComponent<AuroraGame>();EditorSceneManager.SaveScene(s,"Assets/HenrickMan/Scenes/CiudadAurora.unity");BuildPipeline.BuildPlayer(new[]{"Assets/HenrickMan/Scenes/CiudadAurora.unity"},"D:/HenrickMan_ElCorazonDeAurora/Builds/HenrickMan.exe",BuildTarget.StandaloneWindows64,BuildOptions.None);}}

