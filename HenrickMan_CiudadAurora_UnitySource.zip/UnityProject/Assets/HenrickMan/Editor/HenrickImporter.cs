using UnityEditor;
public class HenrickImporter:AssetPostprocessor {void OnPreprocessModel(){if(assetPath.EndsWith("Henrick.fbx")){var m=(ModelImporter)assetImporter;m.animationType=ModelImporterAnimationType.Legacy;m.importAnimation=true;m.materialImportMode=ModelImporterMaterialImportMode.ImportStandard;}}}
