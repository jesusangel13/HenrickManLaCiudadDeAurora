using UnityEditor;using UnityEngine;using UnityEditor.SceneManagement;
[InitializeOnLoad]public class AuroraPendingPrepare{static AuroraPendingPrepare(){EditorApplication.delayCall+=Run;}static void Run(){if(EditorApplication.isPlayingOrWillChangePlaymode||SessionState.GetBool("ZhongliPreparedV5",false))return;SessionState.SetBool("ZhongliPreparedV5",true);PrepareZhongli.Create();}}



