using UnityEngine;
// The source rig uses different bind-pose units across its legacy animations.
[DefaultExecutionOrder(1000)]
public class ZhongliCalibration:MonoBehaviour {
 Transform norm; SkinnedMeshRenderer[] skins; Mesh baked;
 void Start(){norm=transform.Find("Scale normalization");skins=GetComponentsInChildren<SkinnedMeshRenderer>();baked=new Mesh();foreach(var skin in skins)skin.updateWhenOffscreen=true;}
 void LateUpdate(){if(!norm||skins.Length==0)return;bool first=true;Bounds bounds=new Bounds();foreach(var skin in skins){skin.BakeMesh(baked,true);foreach(var vertex in baked.vertices){var point=skin.transform.TransformPoint(vertex);if(first){bounds=new Bounds(point,Vector3.zero);first=false;}else bounds.Encapsulate(point);}}if(first||bounds.size.y<.000001f)return;float factor=2/bounds.size.y;Vector3 basePoint=new Vector3(bounds.center.x,bounds.min.y,bounds.center.z);Vector3 scalePivot=norm.position;norm.localScale*=factor;norm.position+=transform.position-(scalePivot+(basePoint-scalePivot)*factor);}
 void OnDestroy(){if(baked)Destroy(baked);}
}

