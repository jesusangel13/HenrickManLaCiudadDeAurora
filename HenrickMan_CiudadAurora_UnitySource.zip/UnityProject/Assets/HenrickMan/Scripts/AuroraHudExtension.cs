using UnityEngine;

public partial class AuroraGame
{
    static readonly string[] AuroraPowerNames = { "SOLAR", "EÓLICO", "HIDRÁULICO" };
    static readonly Color HealthColor = new Color(0.95f, 0.28f, 0.25f);
    static readonly Color EnergyColor = new Color(0.12f, 0.82f, 1f);

    void DrawMeter(Rect rect, float value, Color fill)
    {
        RectColor(rect, new Color(0.025f, 0.075f, 0.12f, 0.98f));
        float width = Mathf.Max(0f, (rect.width - 4f) * Mathf.Clamp01(value));
        if (width > 0f)
            RectColor(new Rect(rect.x + 2f, rect.y + 2f, width, rect.height - 4f), fill);
    }

    string CurrentObjective()
    {
        if (hero == null || nodes.Count == 0)
            return "RESTAURA LOS TRES RELÉS";

        for (int i = 0; i < nodes.Count; i++)
        {
            GameObject node = nodes[i];
            if (node == null)
                continue;

            Renderer nodeRenderer = node.GetComponent<Renderer>();
            if (nodeRenderer == null || nodeRenderer.sharedMaterial == Mat(cyan))
                continue;

            string affinity = AuroraPowerNames[Mathf.Clamp(i, 0, AuroraPowerNames.Length - 1)];
            if (Vector3.Distance(hero.transform.position, node.transform.position) < 4f)
                return power == i
                    ? "PULSA E PARA ACTIVAR EL RELÉ"
                    : "PULSA Q PARA CAMBIAR A " + affinity;

            return "SIGUIENTE: RELÉ " + (i + 1) + " · " + affinity;
        }

        Drone guardian = drones.Find(d => d.g != null && d.home.z > 65f && d.hp > 0f);
        float coreDistance = Vector3.Distance(hero.transform.position, new Vector3(0f, 1.5f, 76f));
        if (guardian != null)
            return coreDistance < 30f ? "DERROTA AL GUARDIÁN" : "AVANZA AL SANTUARIO";

        return coreDistance < 8f
            ? "PULSA E PARA RESTAURAR EL NÚCLEO"
            : "LLEGA AL CORAZÓN DE AURORA";
    }

    void DrawGameplayHud(float width, float height)
    {
        RectColor(new Rect(25f, 25f, 570f, 154f), new Color(0.015f, 0.035f, 0.065f, 0.94f));
        GUI.Label(new Rect(45f, 35f, 530f, 34f), "MISIÓN: RESTAURAR EL CORAZÓN", body);
        GUI.Label(new Rect(45f, 73f, 530f, 27f),
            "RELÉS " + panels + " / 3   ·   PODER " + AuroraPowerNames[Mathf.Clamp(power, 0, 2)], small);

        GUI.Label(new Rect(45f, 106f, 150f, 24f), "VIDA " + Mathf.CeilToInt(health), small);
        GUI.Label(new Rect(210f, 106f, 150f, 24f), "ENERGÍA " + Mathf.CeilToInt(energy), small);
        GUI.Label(new Rect(375f, 106f, 170f, 24f), "AURORA " + Mathf.FloorToInt(charge) + "%", small);
        DrawMeter(new Rect(45f, 137f, 150f, 12f), health / 100f, HealthColor);
        DrawMeter(new Rect(210f, 137f, 150f, 12f), energy / 100f, EnergyColor);
        DrawMeter(new Rect(375f, 137f, 170f, 12f), charge / 100f, gold);

        RectColor(new Rect(width - 495f, 25f, 470f, 88f), new Color(0.015f, 0.035f, 0.065f, 0.94f));
        GUI.Label(new Rect(width - 475f, 34f, 430f, 22f), "OBJETIVO ACTUAL", small);
        GUI.Label(new Rect(width - 475f, 59f, 430f, 44f), CurrentObjective(),
            new GUIStyle(body) { fontSize = 19, wordWrap = true });

        Drone guardian = drones.Find(d => d.g != null && d.home.z > 65f && d.hp > 0f);
        if (guardian != null && hero != null &&
            Vector3.Distance(hero.transform.position, guardian.g.transform.position) < 28f)
        {
            float bossWidth = 400f;
            float x = (width - bossWidth) * 0.5f;
            RectColor(new Rect(x, 122f, bossWidth, 48f), new Color(0.015f, 0.035f, 0.065f, 0.94f));
            GUI.Label(new Rect(x + 12f, 126f, bossWidth - 24f, 20f), "GUARDIÁN DE NÉMESIS", small);
            DrawMeter(new Rect(x + 12f, 151f, bossWidth - 24f, 10f), guardian.hp / 220f, gold);
        }

        RectColor(new Rect(25f, height - 52f, width - 50f, 34f), new Color(0.015f, 0.035f, 0.065f, 0.9f));
        GUI.Label(new Rect(40f, height - 49f, width - 80f, 28f),
            "WASD mover  ·  Ratón cámara  ·  Espacio salto  ·  Shift correr  ·  Q poder  ·  E activar  ·  C esquivar  ·  Clic izq. atacar  ·  Clic der. habilidad  ·  R Aurora  ·  Esc pausa",
            small);

        if (Time.unscaledTime < messageUntil)
        {
            RectColor(new Rect(width / 2f - 460f, height - 140f, 920f, 65f), navy);
            GUI.Label(new Rect(width / 2f - 440f, height - 130f, 880f, 55f), message, body);
        }
    }
}